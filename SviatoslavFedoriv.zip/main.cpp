#include <iostream>
#include <vector>
#include <cstring>
#include <fstream>
#include <thread>
#include <cmath>
#include <sstream>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <algorithm>
#include <boost/filesystem.hpp>
#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>

namespace fs1 = boost::filesystem;

void print(std::string str){
    std::cout << str << std::endl;
}

void Enter(){
    std::cout<<"Please enter Y[es]/N[o]/C/A[ll]"<<std::endl;
}

std::string get_current_directory(){
    char buf[200];
    getcwd(buf, sizeof(buf));
    return std::string(buf);
}

bool isFileExistInDirectory(std::string dir){
    fs1::path p{dir};
    bool key = fs1::is_regular_file(p);
    return key;
}

std::vector<std::string> vector_of_files_in_directory(){
    std::vector<std::string> dataOfVector;
    {
        std::string path1 = get_current_directory();
        for (auto & p : fs1::directory_iterator(path1))
            dataOfVector.emplace_back( p.path().string());
    }
    return dataOfVector;
}

void Help(){
    std::cout <<">>> mymv [-h|--help] [-f] <oldfile> <newfile>.\n"
              <<">>> mymv [-h|--help] [-f] <oldfile_or_dir_1> <oldfile_or_dir_oldfile2> <oldfile_or_dir_oldfile3>.... <dir>.\n"<< std::endl;
}

std::vector<std::string> split_cmd_line(std::istream& is){
    std::string commandline;
    std::vector<std::string> parsed_command;
    std::getline(is, commandline);
    std::stringstream ss(commandline);
    std::string word;
    while (ss >> word) {
        parsed_command.push_back(word);
    }
    return parsed_command;
}

std::string getFromUser(){

    bool key = true;
    std::vector<std::string>Vector;
    while(key){
        Enter();
        Vector = split_cmd_line(std::cin);
        if(Vector[0] == "Y"|| Vector[0] == "y"|| Vector[0] == "N"|| Vector[0] == "n"|| Vector[0] == "A"|| Vector[0] == "a"|| Vector[0] == "C"|| Vector[0] == "c"){
            key = false;
        }
    }
    return Vector[0];
}

void change_directory(char *dirPATH){
    int erno1 = chdir(dirPATH);
    if (erno1 == -1){
        //std::cout <<"No such file in directory."<< std::endl;
        perror("Error");
        exit(erno1);
    }

}

void changeDirectory(std::string Directory){
    const char *cstr = Directory.c_str();
    change_directory((char *) cstr);
}

std::vector<std::string> Vector_of_all(std::string Directory,std::string MainDirectory){
    std::vector<std::string>Vector;
    changeDirectory(Directory);
    for (auto &p : fs1::recursive_directory_iterator(Directory))
    {
        Vector.emplace_back(p.path().string());
    }
    changeDirectory(MainDirectory);
    return Vector;
}

void m_coopy(fs1::path pathFrom,fs1::path pathTo){
    try { boost::filesystem::copy_file(pathFrom, pathTo, boost::filesystem::copy_option::overwrite_if_exists);
    }
    catch (const boost::filesystem::filesystem_error &e){
        std::cerr << "Error: " << e.what() << std::endl;
    }
}

bool CoopyFileToDirectory(fs1::path pathFrom,fs1::path pathTo,bool keyf,bool keyAll){
    //bool KeyDelete = true;
    if(keyf){
        if(pathFrom.parent_path().empty()){
            boost::filesystem::path dst_path = pathTo /pathFrom.filename().string();
            boost::filesystem::path src_path = get_current_directory() + "/" + pathFrom.filename().string();
            m_coopy(src_path,dst_path);
        }
        else{
            boost::filesystem::path pathTo2 =  pathTo /pathFrom.filename().string();
            m_coopy(pathFrom,pathTo2);
        }
    }
    else{
        if(fs1::is_regular_file(pathTo /pathFrom.filename().string())){
            std::cout<<pathFrom<<std::endl;
            std::string simbol = getFromUser();

            if(simbol == "Y" || simbol == "y"){
                CoopyFileToDirectory(pathFrom,pathTo, not keyf,keyAll);
            }
            else if(simbol == "C" || simbol == "c"){exit(0);}
            else if(simbol == "A" || simbol == "a"){keyAll = true;
                CoopyFileToDirectory(pathFrom,pathTo, not keyf,keyAll);}
        }
        else{
            CoopyFileToDirectory(pathFrom,pathTo, not keyf,keyAll);

        }
    }

    return keyAll;
}

bool ChangePlaceOfFile(fs1::path pathFrom,fs1::path pathTo,bool keyf, bool keyAll){
    bool key = CoopyFileToDirectory(pathFrom,pathTo,keyf,keyAll);
    fs1::remove(pathFrom);
    return key;

}

int main(int argc, char *argv[]) {
    std::string f = "-f";
    std::string MainDirectory = get_current_directory();
    bool keyf = false;
    bool helpKey = false;
    bool keyAll = false;
    std::vector<std::string> DataFromConsol;
    //std::vector<std::string> DataFromConsol1;

    for(int i = 1; i < argc; ++i){

        if(strcmp(argv[i], "-f") == 0 ){
            keyf = true;
        }
        else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            helpKey = true;
        }
        else{
            DataFromConsol.emplace_back(argv[i]);
        }
    }
    if(helpKey){
        Help();
        exit(0);
    }

    std::vector<std::string> VectorAll;
    if(fs1::is_directory(DataFromConsol[DataFromConsol.size()-1])){
        fs1::path PathTo = DataFromConsol[DataFromConsol.size()-1];
        for(int i = 0; i < DataFromConsol.size() - 1; ++i){
            if(fs1::is_regular_file(DataFromConsol[i])){
                fs1::path PahtFrom = DataFromConsol[i];
                bool key1 = ChangePlaceOfFile(PahtFrom,PathTo,keyf,keyAll);
                if(key1){keyf = true;}
            }
            else{
                if ( not (fs1::is_directory(DataFromConsol[i]))) {
                    std::string path = get_current_directory() + "/" + DataFromConsol[i];
                    VectorAll.emplace_back(path);
                }
                else{
                    std::vector<std::string> Vector1 = Vector_of_all(DataFromConsol[i],MainDirectory);
                    for (auto &path : Vector1) {
                        VectorAll.emplace_back(path);
                    }
                }
            }
        }
        for(int i = 0; i < VectorAll.size(); ++i){
            fs1::path PahtFrom = VectorAll[i];
            bool key1 = ChangePlaceOfFile(PahtFrom,PathTo,keyf,keyAll);
            if(key1){keyf = true;}
        }
    }
    else{
        std::cout<<"Incorrect arguments (for more information use mycp -h/--help)"<<std::endl;
        exit(1);
    }
    return 0;
}